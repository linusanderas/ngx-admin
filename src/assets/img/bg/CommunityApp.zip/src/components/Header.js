import React, { Component } from "react";
import { StyleSheet, View } from "react-native";

function Header(props) {
  return (
    <View style={[styles.container, props.style]}>
      <View style={styles.rect}></View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {},
  rect: {
    width: 375,
    height: 50,
    backgroundColor: "#E6E6E6"
  }
});

export default Header;
