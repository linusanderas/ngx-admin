import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import Header from "../components/Header";
import CupertinoSlider from "../components/CupertinoSlider";

function Untitled(props) {
  return (
    <View style={styles.container}>
      <Header style={styles.header}></Header>
      <CupertinoSlider style={styles.cupertinoSlider}></CupertinoSlider>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  header: {
    height: 50,
    width: 375,
    marginTop: 41
  },
  cupertinoSlider: {
    width: 331,
    height: 30,
    marginTop: 285,
    marginLeft: 22
  }
});

export default Untitled;
